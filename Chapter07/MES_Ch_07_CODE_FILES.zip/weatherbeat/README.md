# weatherbeat
A beat to collect data from OpenWeatherMap.org
