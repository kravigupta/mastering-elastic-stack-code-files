# logstash-input-weather
Example input plugin. This should help bootstrap your effort to write your own input plugin!
